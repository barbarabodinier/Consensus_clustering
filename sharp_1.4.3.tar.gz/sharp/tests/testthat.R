library(testthat)
library(sharp)

test_check("sharp")
